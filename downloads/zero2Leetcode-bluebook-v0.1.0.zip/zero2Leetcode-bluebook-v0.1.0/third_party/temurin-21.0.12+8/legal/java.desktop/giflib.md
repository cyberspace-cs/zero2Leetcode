## GIFLIB v6.1.3

### GIFLIB License
```

= MIT LICENSE

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

---------------------------------
The below applies to the following file(s):
giflib/dgif_lib.c
giflib/gifalloc.c
giflib/gif_err.c
giflib/openbsd-reallocarray.c

Copyright (C) 1989 Gershon Elber
Copyright (C) 2008 Otto Moerbeek <otto@drijf.net>
Copyright (C) Eric S. Raymond <esr@thyrsus.com>

SPDX-License-Identifier: MIT


== Authors ==

Gershon Elber <gershon[AT]cs.technion.sc.il>
original giflib code

Toshio Kuratomi <toshio[AT]tiki-lounge.com>
uncompressed gif writing code
former maintainer

Eric Raymond <esr[AT]snark.thyrsus.com>
current as well as long time former maintainer of giflib code

```
